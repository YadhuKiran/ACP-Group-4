import scrapy

class GithubRepoItem(scrapy.Item):
    url = scrapy.Field()
    last_updated = scrapy.Field()
    about = scrapy.Field()
    languages = scrapy.Field()
    commits = scrapy.Field()