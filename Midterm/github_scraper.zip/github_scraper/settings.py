# Scrapy settings for github_scraper project

BOT_NAME = "github_scraper"

SPIDER_MODULES = ["github_scraper.spiders"]
NEWSPIDER_MODULE = "github_scraper.spiders"

ADDONS = {}

# Identify yourself
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36'

# Obey robots.txt rules
ROBOTSTXT_OBEY = True

# Concurrency and throttling settings
#CONCURRENT_REQUESTS = 16
CONCURRENT_REQUESTS_PER_DOMAIN = 1
DOWNLOAD_DELAY = 1

# ✅ Added request headers (important for GitHub)
DEFAULT_REQUEST_HEADERS = {
    "Accept": "text/html",
    "Accept-Language": "en",
}

# Disable cookies (enabled by default)
#COOKIES_ENABLED = False

# Disable Telnet Console (enabled by default)
#TELNETCONSOLE_ENABLED = False

# Enable or disable spider middlewares
#SPIDER_MIDDLEWARES = {
#    "github_scraper.middlewares.GithubScraperSpiderMiddleware": 543,
#}

# Enable or disable downloader middlewares
#DOWNLOADER_MIDDLEWARES = {
#    "github_scraper.middlewares.GithubScraperDownloaderMiddleware": 543,
#}

# Enable or disable extensions
#EXTENSIONS = {
#    "scrapy.extensions.telnet.TelnetConsole": None,
#}

# Configure item pipelines
#ITEM_PIPELINES = {
#    "github_scraper.pipelines.GithubScraperPipeline": 300,
#}

# AutoThrottle (optional but useful)
#AUTOTHROTTLE_ENABLED = True

# HTTP caching (optional)
#HTTPCACHE_ENABLED = True

# Encoding
FEED_EXPORT_ENCODING = "utf-8"