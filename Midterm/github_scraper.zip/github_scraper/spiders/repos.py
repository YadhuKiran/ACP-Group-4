import scrapy
from github_scraper.items import GithubRepoItem

class ReposSpider(scrapy.Spider):
    name = "repos"
    allowed_domains = ["github.com"]
    start_urls = ["https://github.com/ice632069-bytetab?tab=repositories"]

    def parse(self, response):
        # UPDATED selector
        repos = response.css('li[itemprop="owns"]')

        # DEBUG (so you know if it works)
        print("Found repos:", len(repos))

        for repo in repos:
            item = GithubRepoItem()
            
            # UPDATED repo link selector
            relative_url = repo.css('a[itemprop="name codeRepository"]::attr(href)').get()
            if not relative_url:
                continue

            item['url'] = response.urljoin(relative_url)
            
            # Last updated (unchanged)
            item['last_updated'] = repo.css('relative-time::attr(datetime)').get()

            yield response.follow(
                item['url'],
                callback=self.parse_details,
                cb_kwargs={'item': item}
            )

    def parse_details(self, response, item):
        is_empty = response.css('div.blankslate').get() is not None
        
        about_text = response.css('p.f4.my-3::text').get()
        if about_text:
            item['about'] = about_text.strip()
        else:
            if not is_empty:
                item['about'] = response.css('strong.mr-2 a::text').get()
            else:
                item['about'] = None

        if is_empty:
            item['languages'] = None
            item['commits'] = None
        else:
            # Languages (unchanged)
            languages = response.css('ul.list-style-none li span.text-bold::text').getall()
            item['languages'] = ", ".join(languages) if languages else None
            
            # Commits (slightly safer)
            commit_count = response.css('span.d-none.d-sm-inline strong::text').get()
            item['commits'] = commit_count.strip() if commit_count else "0"

        yield item